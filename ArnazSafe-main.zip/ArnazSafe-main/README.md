# Arnazsafe Script Hack Trophy & Crown
Push Crown &amp; Trofi Safe no brutal
